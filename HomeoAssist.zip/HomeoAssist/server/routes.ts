import type { Express } from "express";
import { createServer, type Server } from "http";
import { z } from "zod";
import { storage } from "./storage";
import { aiService } from "./services/ai-service";
import { paymentService } from "./services/payment-service";
import { referenceService } from "./services/reference-service";
import {
  insertUserSchema,
  insertSubscriptionSchema,
  insertConsultationSchema,
  insertHealthRecordSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }

      const user = await storage.createUser(userData);
      res.json({ user: { id: user.id, email: user.email, name: user.name } });
    } catch (error) {
      res.status(400).json({ message: "Invalid user data" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      const user = await storage.getUserByEmail(email);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      res.json({ user: { id: user.id, email: user.email, name: user.name } });
    } catch (error) {
      res.status(500).json({ message: "Login failed" });
    }
  });

  app.post("/api/auth/verify-email", async (req, res) => {
    try {
      const { email, otp } = req.body;
      // In a real implementation, verify OTP here
      const user = await storage.getUserByEmail(email);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      await storage.updateUser(user.id, { isVerified: true });
      res.json({ message: "Email verified successfully" });
    } catch (error) {
      res.status(500).json({ message: "Verification failed" });
    }
  });

  // Subscription routes
  app.get("/api/subscription/:userId", async (req, res) => {
    try {
      const subscription = await storage.getSubscription(req.params.userId);
      res.json({ subscription });
    } catch (error) {
      res.status(500).json({ message: "Failed to get subscription" });
    }
  });

  app.post("/api/payment/create-order", async (req, res) => {
    try {
      const { amount, plan } = req.body;
      const order = await paymentService.createRazorpayOrder(amount, plan);
      res.json({ order });
    } catch (error) {
      res.status(500).json({ message: "Failed to create payment order" });
    }
  });

  app.post("/api/payment/verify", async (req, res) => {
    try {
      const { paymentId, orderId, signature, userId, plan, amount } = req.body;
      
      const verification = await paymentService.verifyPayment(paymentId, orderId, signature);
      
      if (verification.success) {
        // Create or update subscription
        const subscriptionData = insertSubscriptionSchema.parse({
          userId,
          plan: verification.plan,
          amount: verification.amount,
          paymentMethod: "razorpay",
          paymentId: verification.paymentId,
        });

        const subscription = await storage.createSubscription(subscriptionData);
        res.json({ success: true, subscription });
      } else {
        res.status(400).json({ message: verification.message });
      }
    } catch (error) {
      res.status(500).json({ message: "Payment verification failed" });
    }
  });

  app.post("/api/payment/upi", async (req, res) => {
    try {
      const { amount, plan, userId } = req.body;
      const verification = await paymentService.handleUPIPayment(amount, plan);
      
      if (verification.success) {
        const subscriptionData = insertSubscriptionSchema.parse({
          userId,
          plan: verification.plan,
          amount: verification.amount,
          paymentMethod: "upi",
          paymentId: verification.paymentId,
        });

        const subscription = await storage.createSubscription(subscriptionData);
        res.json({ success: true, subscription });
      } else {
        res.status(400).json({ message: verification.message });
      }
    } catch (error) {
      res.status(500).json({ message: "UPI payment failed" });
    }
  });

  // AI consultation routes
  app.post("/api/consultation/analyze", async (req, res) => {
    try {
      const consultationData = insertConsultationSchema.parse(req.body);
      
      // Check if user has active subscription
      const subscription = await storage.getSubscription(consultationData.userId);
      if (!subscription || subscription.status !== "active") {
        return res.status(403).json({ message: "Active subscription required" });
      }

      // Create initial consultation record
      const consultation = await storage.createConsultation(consultationData);
      
      // Analyze symptoms with AI
      const analysis = await aiService.analyzeSymptoms(
        consultationData.symptoms,
        consultationData.language || "en"
      );

      // Update consultation with analysis results
      const updatedConsultation = await storage.updateConsultation(consultation.id, {
        analysis: analysis.analysis,
        remedies: analysis.remedies,
      });

      res.json({ consultation: updatedConsultation, analysis });
    } catch (error) {
      console.error("Analysis error:", error);
      res.status(500).json({ message: "Failed to analyze symptoms" });
    }
  });

  app.get("/api/consultations/:userId", async (req, res) => {
    try {
      const consultations = await storage.getConsultations(req.params.userId);
      res.json({ consultations });
    } catch (error) {
      res.status(500).json({ message: "Failed to get consultations" });
    }
  });

  app.get("/api/consultation/:id", async (req, res) => {
    try {
      const consultation = await storage.getConsultation(req.params.id);
      if (!consultation) {
        return res.status(404).json({ message: "Consultation not found" });
      }
      res.json({ consultation });
    } catch (error) {
      res.status(500).json({ message: "Failed to get consultation" });
    }
  });

  // Reference library routes
  app.get("/api/reference/search", async (req, res) => {
    try {
      const { q: query, lang: language = "en" } = req.query;
      
      if (!query || typeof query !== "string") {
        return res.status(400).json({ message: "Query parameter required" });
      }

      const results = referenceService.searchRemedies(query, language as string);
      res.json({ results });
    } catch (error) {
      res.status(500).json({ message: "Search failed" });
    }
  });

  app.get("/api/reference/remedy/:name", async (req, res) => {
    try {
      const remedy = referenceService.getRemedyByName(req.params.name);
      const materiaMedica = referenceService.getMateriaMedica(req.params.name);
      
      if (!remedy) {
        return res.status(404).json({ message: "Remedy not found" });
      }

      res.json({ remedy, materiaMedica });
    } catch (error) {
      res.status(500).json({ message: "Failed to get remedy information" });
    }
  });

  app.post("/api/reference/dosage", async (req, res) => {
    try {
      const { age, weight, condition } = req.body;
      const dosageInfo = referenceService.calculateDosage(age, weight, condition);
      res.json({ dosageInfo });
    } catch (error) {
      res.status(500).json({ message: "Failed to calculate dosage" });
    }
  });

  // Translation routes
  app.post("/api/translate", async (req, res) => {
    try {
      const { text, targetLanguage } = req.body;
      const translatedText = await aiService.translateText(text, targetLanguage);
      res.json({ translatedText });
    } catch (error) {
      res.status(500).json({ message: "Translation failed" });
    }
  });

  // Health records routes
  app.get("/api/health-records/:userId", async (req, res) => {
    try {
      const records = await storage.getHealthRecords(req.params.userId);
      res.json({ records });
    } catch (error) {
      res.status(500).json({ message: "Failed to get health records" });
    }
  });

  app.post("/api/health-records", async (req, res) => {
    try {
      const recordData = insertHealthRecordSchema.parse(req.body);
      const record = await storage.createHealthRecord(recordData);
      res.json({ record });
    } catch (error) {
      res.status(400).json({ message: "Invalid health record data" });
    }
  });

  // File upload and OCR routes
  app.post("/api/files/upload", async (req, res) => {
    try {
      // In a real implementation, handle file upload with multer
      const { userId, fileName, fileType } = req.body;
      
      const file = await storage.createFile({
        userId,
        fileName,
        fileType,
        filePath: `/uploads/${fileName}`, // Mock file path
      });

      // Simulate OCR processing
      setTimeout(async () => {
        const mockExtractedText = "Patient complains of headache and fatigue for 3 days. Worse in morning, better with rest.";
        const processedText = await aiService.processOCRText(mockExtractedText);
        
        await storage.updateFile(file.id, {
          extractedText: processedText.cleanedText,
          processingStatus: "completed",
        });
      }, 2000);

      res.json({ file });
    } catch (error) {
      res.status(500).json({ message: "File upload failed" });
    }
  });

  app.get("/api/files/:id", async (req, res) => {
    try {
      const file = await storage.getFile(req.params.id);
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }
      res.json({ file });
    } catch (error) {
      res.status(500).json({ message: "Failed to get file" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
