# HomeoAI - AI-Powered Homeopathy Medical Assistant

## Overview

HomeoAI is a comprehensive cross-platform medical assistant application specializing in homeopathic medicine. The application provides AI-powered consultations, personalized remedy suggestions, health tracking, and access to a comprehensive homeopathic reference library. Built as a full-stack web application with a modern React frontend and Express backend, the platform features subscription-based access with integrated payment processing through Razorpay and UPI systems.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite for development and building
- **Routing**: Wouter for lightweight client-side routing
- **UI Components**: Radix UI primitives with shadcn/ui component library for consistent design
- **Styling**: TailwindCSS with CSS variables for theming and responsive design
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Form Handling**: React Hook Form with Zod schema validation for type-safe forms
- **Authentication**: Context-based auth system with local storage persistence

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Storage**: In-memory storage implementation with interface for future database integration
- **API Design**: RESTful endpoints with structured error handling and request logging
- **File Processing**: Built-in file upload and processing capabilities for medical documents

### Data Storage Solutions
- **Database ORM**: Drizzle ORM configured for PostgreSQL with schema-first approach
- **Schema Location**: Shared schema definitions in `/shared/schema.ts` for type safety across frontend and backend
- **Migration System**: Drizzle Kit for database migrations and schema management
- **Current Implementation**: Memory storage with database interface for easy migration to PostgreSQL

### Authentication and Authorization
- **Authentication Method**: Email/password with OTP verification support
- **Session Management**: Stateless authentication with user data stored in localStorage
- **User Roles**: Simple user model with subscription-based feature access
- **Security**: Password validation and email verification workflows

### External Dependencies

#### AI Services
- **Primary AI Provider**: OpenAI GPT models for symptom analysis and remedy suggestions
- **Alternative Provider**: Anthropic Claude SDK integration available as fallback
- **AI Processing**: Custom homeopathic knowledge base integration with classical repertory data

#### Payment Processing
- **Primary Gateway**: Razorpay for card payments, net banking, and wallet transactions
- **UPI Integration**: Direct UPI payment links and QR code generation for Indian market
- **Subscription Plans**: Monthly (₹199), Yearly (₹1200), and Lifetime (₹3000) tiers
- **Payment Verification**: Webhook-based payment confirmation with signature verification

#### Database Services
- **Database Provider**: Neon Database (PostgreSQL) with serverless architecture
- **Connection Management**: Connection pooling through @neondatabase/serverless
- **Session Storage**: PostgreSQL session management with connect-pg-simple

#### Development Tools
- **Build System**: Vite with React plugin and custom Replit integration
- **Development Environment**: Replit-specific plugins for runtime error handling and cartographer
- **Type Safety**: Strict TypeScript configuration with path mapping for clean imports
- **Code Quality**: ESLint and Prettier configurations for consistent code style

#### Homeopathic Reference Data
- **Remedy Database**: Comprehensive materia medica with classical homeopathic remedies
- **Repertory System**: Symptom-to-remedy mapping based on classical repertory
- **Multi-language Support**: English, Hindi, and Telugu language support for remedies and UI
- **Search Functionality**: Advanced search across symptoms, remedies, and repertory rubrics