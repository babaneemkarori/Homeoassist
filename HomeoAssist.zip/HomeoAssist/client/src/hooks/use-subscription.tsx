import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "./use-auth";

interface Subscription {
  id: string;
  plan: string;
  status: string;
  amount: number;
  expiresAt?: string;
  createdAt: string;
}

export function useSubscription() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: subscription, isLoading } = useQuery({
    queryKey: ["/api/subscription", user?.id],
    enabled: !!user?.id,
  });

  const verifyPaymentMutation = useMutation({
    mutationFn: async (paymentData: {
      paymentId: string;
      orderId: string;
      signature: string;
      plan: string;
      amount: number;
    }) => {
      const response = await apiRequest("POST", "/api/payment/verify", {
        ...paymentData,
        userId: user?.id,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/subscription"] });
      toast({
        title: "Payment successful",
        description: "Your subscription has been activated!",
      });
    },
    onError: () => {
      toast({
        title: "Payment verification failed",
        description: "Please contact support if amount was deducted.",
        variant: "destructive",
      });
    },
  });

  const createOrderMutation = useMutation({
    mutationFn: async ({ amount, plan }: { amount: number; plan: string }) => {
      const response = await apiRequest("POST", "/api/payment/create-order", { amount, plan });
      return response.json();
    },
  });

  const upiPaymentMutation = useMutation({
    mutationFn: async ({ amount, plan }: { amount: number; plan: string }) => {
      const response = await apiRequest("POST", "/api/payment/upi", {
        amount,
        plan,
        userId: user?.id,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/subscription"] });
      toast({
        title: "UPI payment successful",
        description: "Your subscription has been activated!",
      });
    },
    onError: () => {
      toast({
        title: "UPI payment failed",
        description: "Please try again or use a different payment method.",
        variant: "destructive",
      });
    },
  });

  const hasActiveSubscription = subscription?.status === "active";

  return {
    subscription: subscription as Subscription | undefined,
    isLoading,
    hasActiveSubscription,
    verifyPayment: verifyPaymentMutation.mutateAsync,
    createOrder: createOrderMutation.mutateAsync,
    upiPayment: upiPaymentMutation.mutateAsync,
    isVerifyingPayment: verifyPaymentMutation.isPending,
    isCreatingOrder: createOrderMutation.isPending,
    isProcessingUPI: upiPaymentMutation.isPending,
  };
}
