export interface RemedyInfo {
  name: string;
  commonName: string;
  symptoms: string[];
  indications: string[];
  dosage: string;
  potency: string[];
  safety: string[];
  hindi?: string;
  telugu?: string;
}

export interface MateriaMedica {
  remedy: string;
  constitution: string;
  mentalState: string;
  physicalSymptoms: string[];
  modalities: {
    worse: string[];
    better: string[];
  };
  keynotes: string[];
}

// Sample homeopathic reference data (in production, this would be a comprehensive database)
export const HOMEOPATHY_REMEDIES: RemedyInfo[] = [
  {
    name: "Arnica Montana",
    commonName: "Mountain Arnica",
    symptoms: ["trauma", "bruising", "shock", "falls", "injuries"],
    indications: [
      "Physical trauma and injuries",
      "Muscle soreness and fatigue",
      "Shock from accidents",
      "Post-surgical healing"
    ],
    dosage: "3-5 pellets under tongue",
    potency: ["6C", "30C", "200C"],
    safety: ["Generally safe", "Avoid if allergic to Asteraceae family"],
    hindi: "अर्निका मोंटाना",
    telugu: "అర్నికా మొంటానా"
  },
  {
    name: "Belladonna",
    commonName: "Deadly Nightshade",
    symptoms: ["fever", "headache", "inflammation", "red face", "throbbing pain"],
    indications: [
      "High fever with hot, red face",
      "Throbbing headaches",
      "Sudden onset conditions",
      "Inflammatory conditions"
    ],
    dosage: "3-5 pellets under tongue",
    potency: ["6C", "30C", "200C"],
    safety: ["Use only in homeopathic doses", "Consult practitioner for children"],
    hindi: "बेलाडोना",
    telugu: "బెల్లడోన్నా"
  },
  {
    name: "Bryonia Alba",
    commonName: "White Bryony",
    symptoms: ["dry cough", "constipation", "headache worse from motion", "irritability"],
    indications: [
      "Dry, painful cough",
      "Headaches worse from motion",
      "Digestive complaints",
      "Joint pain worse from movement"
    ],
    dosage: "3-5 pellets under tongue",
    potency: ["6C", "30C", "200C"],
    safety: ["Generally safe in homeopathic doses"],
    hindi: "ब्रायोनिया अल्बा",
    telugu: "బ్రయోనియా అల్బా"
  },
  {
    name: "Gelsemium",
    commonName: "Yellow Jasmine",
    symptoms: ["anxiety", "trembling", "weakness", "drowsiness", "flu symptoms"],
    indications: [
      "Anticipatory anxiety",
      "Flu with weakness and drowsiness",
      "Trembling from nervousness",
      "Mental fatigue"
    ],
    dosage: "3-5 pellets under tongue",
    potency: ["6C", "30C", "200C"],
    safety: ["Safe in homeopathic doses", "Avoid crude plant material"],
    hindi: "गेल्सेमियम",
    telugu: "గెల్సెమియం"
  },
  {
    name: "Nux Vomica",
    commonName: "Poison Nut",
    symptoms: ["digestive issues", "irritability", "hangover", "constipation", "nausea"],
    indications: [
      "Digestive complaints from overindulgence",
      "Hangover symptoms",
      "Irritability and impatience",
      "Constipation with ineffectual urging"
    ],
    dosage: "3-5 pellets under tongue",
    potency: ["6C", "30C", "200C"],
    safety: ["Safe in homeopathic doses", "Avoid during pregnancy"],
    hindi: "नक्स वोमिका",
    telugu: "నక్స్ వొమికా"
  }
];

export const MATERIA_MEDICA: MateriaMedica[] = [
  {
    remedy: "Arnica Montana",
    constitution: "Strong, robust individuals prone to physical trauma",
    mentalState: "Shock, denial of illness, says nothing is wrong",
    physicalSymptoms: [
      "Soreness and bruising",
      "Everything feels hard",
      "Aversion to being touched",
      "Restlessness from discomfort"
    ],
    modalities: {
      worse: ["Touch", "Motion", "Dampness", "Wine"],
      better: ["Lying down", "Rest", "Cold applications"]
    },
    keynotes: [
      "The great trauma remedy",
      "Bruised, sore feeling all over",
      "Bed feels too hard"
    ]
  },
  {
    remedy: "Belladonna",
    constitution: "Full-blooded, vigorous persons",
    mentalState: "Delirium, rage, violence, biting, striking",
    physicalSymptoms: [
      "Hot, red face with cold extremities",
      "Throbbing pains",
      "Sudden onset of symptoms",
      "High fever with sweating"
    ],
    modalities: {
      worse: ["Touch", "Light", "Noise", "Motion"],
      better: ["Rest", "Darkness", "Quiet"]
    },
    keynotes: [
      "Sudden onset",
      "Heat, redness, throbbing",
      "Right-sided complaints"
    ]
  }
];

export const REPERTORY_RUBRICS = {
  "Head": {
    "Pain": {
      "general": ["Belladonna", "Bryonia", "Gelsemium", "Nux Vomica"],
      "throbbing": ["Belladonna", "Glonoine", "Natrum Mur"],
      "worse_motion": ["Bryonia", "Spigelia", "Cocculus"],
      "better_pressure": ["Apis", "Argentum Nit", "Pulsatilla"]
    },
    "Vertigo": {
      "general": ["Gelsemium", "Cocculus", "Petroleum"],
      "worse_motion": ["Cocculus", "Tabacum", "Petroleum"]
    }
  },
  "Mind": {
    "Anxiety": {
      "general": ["Aconitum", "Arsenicum", "Gelsemium"],
      "anticipatory": ["Gelsemium", "Lycopodium", "Argentum Nit"],
      "from_fright": ["Aconitum", "Opium", "Stramonium"]
    },
    "Irritability": {
      "general": ["Nux Vomica", "Chamomilla", "Lycopodium"],
      "morning": ["Nux Vomica", "Bryonia", "Sulphur"]
    }
  },
  "Stomach": {
    "Nausea": {
      "general": ["Nux Vomica", "Ipecac", "Petroleum"],
      "morning": ["Nux Vomica", "Pulsatilla", "Sepia"],
      "from_motion": ["Cocculus", "Petroleum", "Tabacum"]
    }
  }
};
