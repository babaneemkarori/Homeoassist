import { HOMEOPATHY_REMEDIES, MATERIA_MEDICA, REPERTORY_RUBRICS, RemedyInfo, MateriaMedica } from "../data/homeopathy-reference";

export interface SearchResult {
  type: "remedy" | "symptom" | "rubric";
  title: string;
  content: string;
  relevance: number;
  remedy?: RemedyInfo;
  materiaMedica?: MateriaMedica;
}

export class ReferenceService {
  searchRemedies(query: string, language: string = "en"): SearchResult[] {
    const normalizedQuery = query.toLowerCase();
    const results: SearchResult[] = [];

    // Search in remedy names and symptoms
    HOMEOPATHY_REMEDIES.forEach(remedy => {
      let relevance = 0;
      
      // Check remedy name match
      if (remedy.name.toLowerCase().includes(normalizedQuery) ||
          remedy.commonName.toLowerCase().includes(normalizedQuery)) {
        relevance += 10;
      }

      // Check symptoms match
      remedy.symptoms.forEach(symptom => {
        if (symptom.toLowerCase().includes(normalizedQuery)) {
          relevance += 5;
        }
      });

      // Check indications match
      remedy.indications.forEach(indication => {
        if (indication.toLowerCase().includes(normalizedQuery)) {
          relevance += 3;
        }
      });

      if (relevance > 0) {
        const title = language === "hi" && remedy.hindi ? remedy.hindi : remedy.name;
        results.push({
          type: "remedy",
          title,
          content: this.formatRemedyContent(remedy, language),
          relevance,
          remedy
        });
      }
    });

    // Search in materia medica
    MATERIA_MEDICA.forEach(mm => {
      let relevance = 0;
      
      if (mm.remedy.toLowerCase().includes(normalizedQuery)) {
        relevance += 8;
      }

      mm.physicalSymptoms.forEach(symptom => {
        if (symptom.toLowerCase().includes(normalizedQuery)) {
          relevance += 4;
        }
      });

      if (mm.mentalState.toLowerCase().includes(normalizedQuery)) {
        relevance += 6;
      }

      if (relevance > 0) {
        results.push({
          type: "remedy",
          title: mm.remedy,
          content: this.formatMateriaMedicaContent(mm),
          relevance,
          materiaMedica: mm
        });
      }
    });

    // Search in repertory rubrics
    this.searchRepertoryRubrics(normalizedQuery).forEach(result => {
      results.push(result);
    });

    // Sort by relevance
    return results.sort((a, b) => b.relevance - a.relevance).slice(0, 20);
  }

  private searchRepertoryRubrics(query: string): SearchResult[] {
    const results: SearchResult[] = [];

    Object.entries(REPERTORY_RUBRICS).forEach(([section, symptoms]) => {
      if (section.toLowerCase().includes(query)) {
        results.push({
          type: "rubric",
          title: section,
          content: this.formatRubricContent(section, symptoms),
          relevance: 7
        });
      }

      Object.entries(symptoms).forEach(([symptom, details]) => {
        if (symptom.toLowerCase().includes(query)) {
          results.push({
            type: "rubric",
            title: `${section}: ${symptom}`,
            content: this.formatRubricContent(`${section}: ${symptom}`, details),
            relevance: 5
          });
        }

        if (typeof details === "object") {
          Object.entries(details).forEach(([subSymptom, remedies]) => {
            if (subSymptom.toLowerCase().includes(query)) {
              results.push({
                type: "rubric",
                title: `${section}: ${symptom}, ${subSymptom}`,
                content: this.formatRubricContent(`${section}: ${symptom}, ${subSymptom}`, remedies),
                relevance: 3
              });
            }
          });
        }
      });
    });

    return results;
  }

  private formatRemedyContent(remedy: RemedyInfo, language: string): string {
    return `
**Common Name:** ${remedy.commonName}

**Main Indications:**
${remedy.indications.map(indication => `• ${indication}`).join('\n')}

**Key Symptoms:**
${remedy.symptoms.map(symptom => `• ${symptom}`).join('\n')}

**Dosage:** ${remedy.dosage}
**Potencies:** ${remedy.potency.join(', ')}

**Safety Notes:**
${remedy.safety.map(note => `• ${note}`).join('\n')}
    `.trim();
  }

  private formatMateriaMedicaContent(mm: MateriaMedica): string {
    return `
**Constitution:** ${mm.constitution}

**Mental State:** ${mm.mentalState}

**Physical Symptoms:**
${mm.physicalSymptoms.map(symptom => `• ${symptom}`).join('\n')}

**Modalities:**
*Worse:* ${mm.modalities.worse.join(', ')}
*Better:* ${mm.modalities.better.join(', ')}

**Key Notes:**
${mm.keynotes.map(note => `• ${note}`).join('\n')}
    `.trim();
  }

  private formatRubricContent(title: string, content: any): string {
    if (Array.isArray(content)) {
      return `**Remedies:** ${content.join(', ')}`;
    }
    
    if (typeof content === "object") {
      return Object.entries(content)
        .map(([key, remedies]) => `**${key}:** ${Array.isArray(remedies) ? remedies.join(', ') : remedies}`)
        .join('\n');
    }
    
    return content.toString();
  }

  getRemedyByName(name: string): RemedyInfo | undefined {
    return HOMEOPATHY_REMEDIES.find(remedy => 
      remedy.name.toLowerCase() === name.toLowerCase() ||
      remedy.commonName.toLowerCase() === name.toLowerCase()
    );
  }

  getMateriaMedica(remedyName: string): MateriaMedica | undefined {
    return MATERIA_MEDICA.find(mm => 
      mm.remedy.toLowerCase() === remedyName.toLowerCase()
    );
  }

  calculateDosage(age: number, weight?: number, condition?: string): {
    potency: string;
    frequency: string;
    duration: string;
    notes: string[];
  } {
    let potency = "30C";
    let frequency = "3 times daily";
    let duration = "7-14 days";
    const notes: string[] = [];

    // Age-based adjustments
    if (age < 2) {
      potency = "6C";
      frequency = "2 times daily";
      notes.push("For infants, dissolve pellets in water");
    } else if (age < 12) {
      potency = "12C";
      frequency = "2-3 times daily";
      notes.push("For children, use lower potency");
    } else if (age > 65) {
      frequency = "2 times daily";
      notes.push("For elderly, start with lower frequency");
    }

    // Condition-based adjustments
    if (condition === "acute") {
      frequency = "every 2-4 hours until improvement";
      duration = "2-3 days";
      notes.push("For acute conditions, frequent doses initially");
    } else if (condition === "chronic") {
      potency = "200C";
      frequency = "once daily";
      duration = "2-4 weeks";
      notes.push("For chronic conditions, higher potency less frequently");
    }

    notes.push("Stop when symptoms improve");
    notes.push("Consult practitioner if no improvement in 3 days");

    return { potency, frequency, duration, notes };
  }
}

export const referenceService = new ReferenceService();
