import { Button } from "@/components/ui/button";
import { useState } from "react";

const languages = [
  { code: "en", label: "EN", name: "English" },
  { code: "hi", label: "हिं", name: "Hindi" },
  { code: "te", label: "TE", name: "Telugu" },
];

export default function LanguageToggle() {
  const [currentLanguage, setCurrentLanguage] = useState("en");

  const handleLanguageChange = (langCode: string) => {
    setCurrentLanguage(langCode);
    // Here you would typically update the app's language context
    localStorage.setItem("homeo-language", langCode);
  };

  return (
    <div className="flex items-center space-x-2" data-testid="language-toggle">
      {languages.map((lang) => (
        <Button
          key={lang.code}
          variant={currentLanguage === lang.code ? "default" : "outline"}
          size="sm"
          onClick={() => handleLanguageChange(lang.code)}
          className="px-3 py-1 text-sm"
          data-testid={`language-${lang.code}`}
        >
          {lang.label}
        </Button>
      ))}
    </div>
  );
}
