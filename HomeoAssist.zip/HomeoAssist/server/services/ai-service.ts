import OpenAI from "openai";
import { HOMEOPATHY_REMEDIES, REPERTORY_RUBRICS, MATERIA_MEDICA } from "../data/homeopathy-reference";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const apiKey = process.env.OPENAI_API_KEY || process.env.VITE_OPENAI_API_KEY;
let openai: OpenAI | null = null;

if (apiKey) {
  openai = new OpenAI({ apiKey });
}

function ensureAPIKey(): OpenAI {
  if (!openai) {
    throw new Error("AI functionality is not available. OpenAI API key is required. Please add your OPENAI_API_KEY to the environment variables.");
  }
  return openai;
}

export interface SymptomAnalysis {
  symptoms: string[];
  repertoryRubrics: string[];
  severity: "mild" | "moderate" | "severe";
  duration: string;
  modalities: {
    worse: string[];
    better: string[];
  };
}

export interface RemedySuggestion {
  remedy: string;
  potency: string;
  dosage: string;
  confidence: number;
  reasoning: string;
  safety: string[];
}

export interface AIAnalysisResult {
  analysis: SymptomAnalysis;
  remedies: RemedySuggestion[];
  warnings: string[];
  followUpQuestions: string[];
}

export class AIService {
  async analyzeSymptoms(symptoms: string, language: string = "en"): Promise<AIAnalysisResult> {
    try {
      const systemPrompt = `You are an expert homeopathic practitioner with deep knowledge of classical homeopathy, repertory, and materia medica. Analyze the patient's symptoms and provide remedy suggestions based on homeopathic principles.

Important guidelines:
1. Always prioritize patient safety
2. Suggest consulting a qualified practitioner for serious conditions
3. Base recommendations on classical homeopathic principles
4. Consider constitutional types and modalities
5. Provide clear reasoning for remedy suggestions

Available remedies in database: ${HOMEOPATHY_REMEDIES.map(r => r.name).join(", ")}

Respond in JSON format with the following structure:
{
  "analysis": {
    "symptoms": ["extracted symptom 1", "symptom 2"],
    "repertoryRubrics": ["Mind: Anxiety", "Head: Pain, throbbing"],
    "severity": "mild|moderate|severe",
    "duration": "acute|chronic|recent onset",
    "modalities": {
      "worse": ["factors that worsen symptoms"],
      "better": ["factors that improve symptoms"]
    }
  },
  "remedies": [
    {
      "remedy": "Remedy name",
      "potency": "30C",
      "dosage": "3-5 pellets 3 times daily",
      "confidence": 0.85,
      "reasoning": "Why this remedy matches",
      "safety": ["safety considerations"]
    }
  ],
  "warnings": ["Important safety warnings"],
  "followUpQuestions": ["Questions to better understand the case"]
}`;

      const userPrompt = `Patient symptoms: ${symptoms}

Please analyze these symptoms according to homeopathic principles and suggest appropriate remedies. Consider:
1. The totality of symptoms
2. Mental and emotional state
3. Physical symptoms and their characteristics
4. Modalities (what makes symptoms better or worse)
5. Constitutional type

Language for response: ${language}`;

      const client = ensureAPIKey();
      const response = await client.chat.completions.create({
        model: "gpt-5",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ],
        response_format: { type: "json_object" },
        temperature: 0.3,
      });

      const result = JSON.parse(response.choices[0].message.content || "{}");
      
      // Validate and enhance the response with our reference data
      const enhancedResult = this.enhanceWithReferenceData(result);
      
      return enhancedResult;
    } catch (error) {
      console.error("AI Analysis Error:", error);
      throw new Error("Failed to analyze symptoms. Please try again.");
    }
  }

  private enhanceWithReferenceData(result: any): AIAnalysisResult {
    // Enhance remedy suggestions with our reference data
    const enhancedRemedies = result.remedies?.map((remedy: any) => {
      const referenceRemedy = HOMEOPATHY_REMEDIES.find(
        r => r.name.toLowerCase().includes(remedy.remedy.toLowerCase()) ||
             remedy.remedy.toLowerCase().includes(r.name.toLowerCase())
      );

      if (referenceRemedy) {
        return {
          ...remedy,
          safety: referenceRemedy.safety,
          potency: referenceRemedy.potency[0] || remedy.potency,
        };
      }
      return remedy;
    }) || [];

    // Add safety warnings
    const warnings = [
      "This is for educational purposes only",
      "Consult a qualified homeopathic practitioner for proper treatment",
      "Seek immediate medical attention for serious or emergency conditions",
      "Stop taking if symptoms worsen or new symptoms appear",
      ...(result.warnings || [])
    ];

    return {
      analysis: result.analysis || {
        symptoms: [],
        repertoryRubrics: [],
        severity: "mild",
        duration: "recent onset",
        modalities: { worse: [], better: [] }
      },
      remedies: enhancedRemedies,
      warnings,
      followUpQuestions: result.followUpQuestions || [
        "How long have you had these symptoms?",
        "What makes the symptoms better or worse?",
        "Are there any emotional or mental symptoms?",
        "Have you tried any treatments before?"
      ]
    };
  }

  async translateText(text: string, targetLanguage: string): Promise<string> {
    if (targetLanguage === "en") return text;

    try {
      const client = ensureAPIKey();
      const response = await client.chat.completions.create({
        model: "gpt-5",
        messages: [
          {
            role: "system",
            content: `Translate the following medical/homeopathic text to ${targetLanguage}. Maintain medical accuracy and use appropriate medical terminology.`
          },
          {
            role: "user",
            content: text
          }
        ],
        temperature: 0.1,
      });

      return response.choices[0].message.content || text;
    } catch (error) {
      console.error("Translation Error:", error);
      return text; // Return original text if translation fails
    }
  }

  async processOCRText(extractedText: string): Promise<{
    cleanedText: string;
    medicalTerms: string[];
    confidence: number;
  }> {
    try {
      const client = ensureAPIKey();
      const response = await client.chat.completions.create({
        model: "gpt-5",
        messages: [
          {
            role: "system",
            content: `You are processing OCR text from medical documents. Clean up the text, identify medical terms, and assess OCR quality. Respond in JSON format:
{
  "cleanedText": "corrected text",
  "medicalTerms": ["identified medical terms"],
  "confidence": 0.95
}`
          },
          {
            role: "user",
            content: `OCR extracted text: ${extractedText}`
          }
        ],
        response_format: { type: "json_object" },
      });

      return JSON.parse(response.choices[0].message.content || "{}");
    } catch (error) {
      console.error("OCR Processing Error:", error);
      return {
        cleanedText: extractedText,
        medicalTerms: [],
        confidence: 0.5
      };
    }
  }
}

export const aiService = new AIService();
