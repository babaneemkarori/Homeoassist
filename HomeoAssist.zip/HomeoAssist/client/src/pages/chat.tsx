import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useSubscription } from "@/hooks/use-subscription";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import ChatInterface from "@/components/chat-interface";
import FileUpload from "@/components/file-upload";
import { Link } from "wouter";
import { AlertCircle, MessageSquare, Mic, Upload } from "lucide-react";

export default function Chat() {
  const { user } = useAuth();
  const { hasActiveSubscription } = useSubscription();
  const [activeTab, setActiveTab] = useState<"chat" | "upload">("chat");

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card>
          <CardContent className="p-6 text-center">
            <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Please login to access AI chat</p>
            <Link href="/login">
              <Button className="mt-4">Login</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!hasActiveSubscription) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="p-6 text-center">
            <AlertCircle className="w-12 h-12 text-accent mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-foreground mb-2">Subscription Required</h2>
            <p className="text-muted-foreground mb-4">
              Please subscribe to access AI consultations and get personalized homeopathic remedy suggestions.
            </p>
            <Link href="/subscription">
              <Button className="bg-accent text-accent-foreground" data-testid="subscribe-to-chat">
                Subscribe Now
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-8 px-4" data-testid="chat-page">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">AI Medical Assistant</h1>
          <p className="text-muted-foreground">
            Describe your symptoms and get personalized homeopathic remedy suggestions
          </p>
        </div>

        {/* Input Method Tabs */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex space-x-2 mb-4">
              <Button
                variant={activeTab === "chat" ? "default" : "outline"}
                onClick={() => setActiveTab("chat")}
                className="flex items-center space-x-2"
                data-testid="tab-chat"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Text Chat</span>
              </Button>
              <Button
                variant={activeTab === "upload" ? "default" : "outline"}
                onClick={() => setActiveTab("upload")}
                className="flex items-center space-x-2"
                data-testid="tab-upload"
              >
                <Upload className="w-4 h-4" />
                <span>Upload Documents</span>
              </Button>
            </div>

            {activeTab === "chat" && (
              <div className="text-sm text-muted-foreground">
                <p>💬 Type your symptoms or speak directly to the AI assistant</p>
                <p>🎤 Click the microphone icon for voice input</p>
                <p>🌍 Switch languages using the toggle in the navigation</p>
              </div>
            )}

            {activeTab === "upload" && (
              <div className="text-sm text-muted-foreground">
                <p>📄 Upload medical reports, prescriptions, or handwritten notes</p>
                <p>🔍 AI will extract and analyze text using OCR/OMR technology</p>
                <p>📱 Supports PDF, images, and scanned documents</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Main Content Area */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-3">
            {activeTab === "chat" && <ChatInterface />}
            {activeTab === "upload" && <FileUpload />}
          </div>

          {/* Side Panel */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Link href="/reference">
                    <Button variant="ghost" className="w-full justify-start" data-testid="quick-search-remedies">
                      <MessageSquare className="w-4 h-4 mr-2 text-primary" />
                      Search Remedies
                    </Button>
                  </Link>
                  <Button variant="ghost" className="w-full justify-start" data-testid="quick-dosage-calculator">
                    <AlertCircle className="w-4 h-4 mr-2 text-primary" />
                    Dosage Calculator
                  </Button>
                  <Button variant="ghost" className="w-full justify-start" data-testid="quick-emergency-finder">
                    <AlertCircle className="w-4 h-4 mr-2 text-accent" />
                    Emergency Finder
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Health Tips */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Health Tips</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">💧 Stay Hydrated</p>
                    <p className="text-muted-foreground">Drink plenty of water to support remedy absorption</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">⏰ Timing Matters</p>
                    <p className="text-muted-foreground">Take remedies 30 minutes before or after meals</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground">📝 Track Progress</p>
                    <p className="text-muted-foreground">Monitor your symptoms and remedy responses</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Emergency Contacts */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg text-destructive">Emergency</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <p className="font-medium text-foreground">For serious conditions:</p>
                  <p className="text-muted-foreground">• Call emergency services: 102</p>
                  <p className="text-muted-foreground">• Contact your doctor immediately</p>
                  <p className="text-muted-foreground">• Don't rely solely on homeopathy</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
