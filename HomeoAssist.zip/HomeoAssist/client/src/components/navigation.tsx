import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Leaf, Menu, User, MessageSquare, Book, CreditCard, Settings } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import LanguageToggle from "./language-toggle";

export default function Navigation() {
  const [location] = useLocation();
  const { user, logout } = useAuth();

  if (!user) return null;

  const navItems = [
    { path: "/dashboard", label: "Dashboard", icon: MessageSquare },
    { path: "/chat", label: "AI Chat", icon: MessageSquare },
    { path: "/reference", label: "Reference", icon: Book },
    { path: "/subscription", label: "Subscription", icon: CreditCard },
    { path: "/profile", label: "Profile", icon: Settings },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-card border-b border-border shadow-sm" data-testid="navigation">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-4">
            <Link href="/dashboard">
              <div className="flex items-center space-x-2 cursor-pointer" data-testid="logo">
                <Leaf className="text-primary text-2xl" />
                <span className="text-xl font-bold text-foreground">HomeoAI</span>
              </div>
            </Link>
            <LanguageToggle />
          </div>

          <div className="hidden md:flex items-center space-x-6">
            {navItems.map((item) => (
              <Link key={item.path} href={item.path}>
                <Button
                  variant={location === item.path ? "default" : "ghost"}
                  className="text-sm"
                  data-testid={`nav-${item.label.toLowerCase()}`}
                >
                  <item.icon className="w-4 h-4 mr-2" />
                  {item.label}
                </Button>
              </Link>
            ))}
          </div>

          <div className="flex items-center space-x-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" data-testid="user-menu">
                  <User className="w-4 h-4 mr-2" />
                  {user.name || user.email}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem asChild>
                  <Link href="/profile" data-testid="profile-link">
                    <Settings className="w-4 h-4 mr-2" />
                    Profile
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={logout} data-testid="logout-button">
                  <User className="w-4 h-4 mr-2" />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button variant="ghost" size="sm" className="md:hidden" data-testid="mobile-menu">
              <Menu className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}
