import {
  type User,
  type InsertUser,
  type Subscription,
  type InsertSubscription,
  type Consultation,
  type InsertConsultation,
  type HealthRecord,
  type InsertHealthRecord,
  type UploadedFile,
  type InsertFile,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;

  // Subscription methods
  getSubscription(userId: string): Promise<Subscription | undefined>;
  createSubscription(subscription: InsertSubscription): Promise<Subscription>;
  updateSubscription(id: string, updates: Partial<Subscription>): Promise<Subscription | undefined>;

  // Consultation methods
  getConsultations(userId: string): Promise<Consultation[]>;
  createConsultation(consultation: InsertConsultation): Promise<Consultation>;
  getConsultation(id: string): Promise<Consultation | undefined>;
  updateConsultation(id: string, updates: Partial<Consultation>): Promise<Consultation | undefined>;

  // Health record methods
  getHealthRecords(userId: string): Promise<HealthRecord[]>;
  createHealthRecord(record: InsertHealthRecord): Promise<HealthRecord>;

  // File methods
  createFile(file: InsertFile): Promise<UploadedFile>;
  getFile(id: string): Promise<UploadedFile | undefined>;
  updateFile(id: string, updates: Partial<UploadedFile>): Promise<UploadedFile | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private subscriptions: Map<string, Subscription> = new Map();
  private consultations: Map<string, Consultation> = new Map();
  private healthRecords: Map<string, HealthRecord> = new Map();
  private files: Map<string, UploadedFile> = new Map();

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = {
      email: insertUser.email,
      password: insertUser.password || null,
      name: insertUser.name || null,
      phone: insertUser.phone || null,
      language: insertUser.language || "en",
      id,
      isVerified: false,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getSubscription(userId: string): Promise<Subscription | undefined> {
    return Array.from(this.subscriptions.values()).find(sub => sub.userId === userId);
  }

  async createSubscription(insertSubscription: InsertSubscription): Promise<Subscription> {
    const id = randomUUID();
    const subscription: Subscription = {
      userId: insertSubscription.userId,
      plan: insertSubscription.plan,
      amount: insertSubscription.amount,
      paymentMethod: insertSubscription.paymentMethod || null,
      paymentId: insertSubscription.paymentId || null,
      id,
      status: "active",
      expiresAt: this.calculateExpiryDate(insertSubscription.plan),
      createdAt: new Date(),
    };
    this.subscriptions.set(id, subscription);
    return subscription;
  }

  async updateSubscription(id: string, updates: Partial<Subscription>): Promise<Subscription | undefined> {
    const subscription = this.subscriptions.get(id);
    if (!subscription) return undefined;
    
    const updatedSubscription = { ...subscription, ...updates };
    this.subscriptions.set(id, updatedSubscription);
    return updatedSubscription;
  }

  async getConsultations(userId: string): Promise<Consultation[]> {
    return Array.from(this.consultations.values())
      .filter(consultation => consultation.userId === userId)
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0));
  }

  async createConsultation(insertConsultation: InsertConsultation): Promise<Consultation> {
    const id = randomUUID();
    const consultation: Consultation = {
      ...insertConsultation,
      id,
      analysis: null,
      remedies: null,
      createdAt: new Date(),
      language: insertConsultation.language || "en",
    };
    this.consultations.set(id, consultation);
    return consultation;
  }

  async getConsultation(id: string): Promise<Consultation | undefined> {
    return this.consultations.get(id);
  }

  async updateConsultation(id: string, updates: Partial<Consultation>): Promise<Consultation | undefined> {
    const consultation = this.consultations.get(id);
    if (!consultation) return undefined;
    
    const updatedConsultation = { ...consultation, ...updates };
    this.consultations.set(id, updatedConsultation);
    return updatedConsultation;
  }

  async getHealthRecords(userId: string): Promise<HealthRecord[]> {
    return Array.from(this.healthRecords.values())
      .filter(record => record.userId === userId)
      .sort((a, b) => (b.date?.getTime() || 0) - (a.date?.getTime() || 0));
  }

  async createHealthRecord(insertRecord: InsertHealthRecord): Promise<HealthRecord> {
    const id = randomUUID();
    const record: HealthRecord = {
      ...insertRecord,
      id,
      date: new Date(),
      createdAt: new Date(),
      familyMember: insertRecord.familyMember || "self",
    };
    this.healthRecords.set(id, record);
    return record;
  }

  async createFile(insertFile: InsertFile): Promise<UploadedFile> {
    const id = randomUUID();
    const file: UploadedFile = {
      ...insertFile,
      id,
      extractedText: null,
      processingStatus: "pending",
      createdAt: new Date(),
    };
    this.files.set(id, file);
    return file;
  }

  async getFile(id: string): Promise<UploadedFile | undefined> {
    return this.files.get(id);
  }

  async updateFile(id: string, updates: Partial<UploadedFile>): Promise<UploadedFile | undefined> {
    const file = this.files.get(id);
    if (!file) return undefined;
    
    const updatedFile = { ...file, ...updates };
    this.files.set(id, updatedFile);
    return updatedFile;
  }

  private calculateExpiryDate(plan: string): Date | null {
    const now = new Date();
    switch (plan) {
      case "monthly":
        return new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
      case "yearly":
        return new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000);
      case "lifetime":
        return null; // No expiry for lifetime
      default:
        return now;
    }
  }
}

export const storage = new MemStorage();
